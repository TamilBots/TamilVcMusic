from TamilVc.function.admins import admins
from TamilVc.function.admins import get
from TamilVc.function.admins import set

__all__ = ["set", "get", "admins"]
